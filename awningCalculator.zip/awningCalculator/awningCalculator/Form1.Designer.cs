﻿namespace awningCalculator
{
    partial class awningCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(awningCalculator));
            this.label1 = new System.Windows.Forms.Label();
            this.txtWidth = new System.Windows.Forms.TextBox();
            this.radFabric = new System.Windows.Forms.RadioButton();
            this.radMetal = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.radNoPowder = new System.Windows.Forms.RadioButton();
            this.radYesPowder = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtEstimate = new System.Windows.Forms.TextBox();
            this.powdercoatToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.materialToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.pcbAwning = new System.Windows.Forms.PictureBox();
            this.pcbFabricAwning = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbAwning)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbFabricAwning)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(35, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter width";
            // 
            // txtWidth
            // 
            this.txtWidth.Location = new System.Drawing.Point(115, 67);
            this.txtWidth.Name = "txtWidth";
            this.txtWidth.Size = new System.Drawing.Size(40, 20);
            this.txtWidth.TabIndex = 1;
            // 
            // radFabric
            // 
            this.radFabric.AutoSize = true;
            this.radFabric.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radFabric.Location = new System.Drawing.Point(26, 19);
            this.radFabric.Name = "radFabric";
            this.radFabric.Size = new System.Drawing.Size(56, 17);
            this.radFabric.TabIndex = 5;
            this.radFabric.TabStop = true;
            this.radFabric.Text = "Fabric";
            this.radFabric.UseVisualStyleBackColor = true;
            // 
            // radMetal
            // 
            this.radMetal.AutoSize = true;
            this.radMetal.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radMetal.Location = new System.Drawing.Point(88, 19);
            this.radMetal.Name = "radMetal";
            this.radMetal.Size = new System.Drawing.Size(54, 17);
            this.radMetal.TabIndex = 6;
            this.radMetal.TabStop = true;
            this.radMetal.Text = "Metal";
            this.radMetal.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Leelawadee UI Semilight", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(59, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(165, 28);
            this.label3.TabIndex = 7;
            this.label3.Text = "Awning Calculator";
            // 
            // radNoPowder
            // 
            this.radNoPowder.AutoSize = true;
            this.radNoPowder.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radNoPowder.Location = new System.Drawing.Point(77, 19);
            this.radNoPowder.Name = "radNoPowder";
            this.radNoPowder.Size = new System.Drawing.Size(40, 17);
            this.radNoPowder.TabIndex = 12;
            this.radNoPowder.TabStop = true;
            this.radNoPowder.Text = "No";
            this.radNoPowder.UseVisualStyleBackColor = true;
            // 
            // radYesPowder
            // 
            this.radYesPowder.AutoSize = true;
            this.radYesPowder.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radYesPowder.Location = new System.Drawing.Point(23, 19);
            this.radYesPowder.Name = "radYesPowder";
            this.radYesPowder.Size = new System.Drawing.Size(41, 17);
            this.radYesPowder.TabIndex = 11;
            this.radYesPowder.TabStop = true;
            this.radYesPowder.Text = "Yes";
            this.radYesPowder.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radNoPowder);
            this.groupBox1.Controls.Add(this.radYesPowder);
            this.groupBox1.Location = new System.Drawing.Point(38, 181);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(177, 54);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Powdercoated Frame";
            this.powdercoatToolTip.SetToolTip(this.groupBox1, "Standard awning frames comes in square aluminum \r\ntubing with no powdercoating or" +
        " paint finish. \r\n\r\nAn additional charge will be added if yes is selected.\r\n");
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radMetal);
            this.groupBox2.Controls.Add(this.radFabric);
            this.groupBox2.Location = new System.Drawing.Point(38, 108);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(179, 54);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Select Material";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(35, 254);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "Price Estimate";
            // 
            // txtEstimate
            // 
            this.txtEstimate.Location = new System.Drawing.Point(115, 251);
            this.txtEstimate.Name = "txtEstimate";
            this.txtEstimate.ReadOnly = true;
            this.txtEstimate.Size = new System.Drawing.Size(75, 20);
            this.txtEstimate.TabIndex = 16;
            // 
            // powdercoatToolTip
            // 
            this.powdercoatToolTip.Tag = "";
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(38, 283);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(75, 23);
            this.btnCalculate.TabIndex = 17;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(119, 283);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 18;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(200, 283);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 19;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(161, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "ft.";
            // 
            // pcbAwning
            // 
            this.pcbAwning.Image = ((System.Drawing.Image)(resources.GetObject("pcbAwning.Image")));
            this.pcbAwning.Location = new System.Drawing.Point(283, 50);
            this.pcbAwning.Name = "pcbAwning";
            this.pcbAwning.Size = new System.Drawing.Size(283, 234);
            this.pcbAwning.TabIndex = 21;
            this.pcbAwning.TabStop = false;
            this.pcbAwning.Visible = false;
            // 
            // pcbFabricAwning
            // 
            this.pcbFabricAwning.Image = ((System.Drawing.Image)(resources.GetObject("pcbFabricAwning.Image")));
            this.pcbFabricAwning.Location = new System.Drawing.Point(283, 50);
            this.pcbFabricAwning.Name = "pcbFabricAwning";
            this.pcbFabricAwning.Size = new System.Drawing.Size(283, 234);
            this.pcbFabricAwning.TabIndex = 22;
            this.pcbFabricAwning.TabStop = false;
            this.pcbFabricAwning.Visible = false;
            // 
            // awningCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(578, 317);
            this.Controls.Add(this.pcbFabricAwning);
            this.Controls.Add(this.pcbAwning);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtEstimate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtWidth);
            this.Controls.Add(this.label1);
            this.Name = "awningCalculator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbAwning)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbFabricAwning)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtWidth;
        private System.Windows.Forms.RadioButton radFabric;
        private System.Windows.Forms.RadioButton radMetal;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton radNoPowder;
        private System.Windows.Forms.RadioButton radYesPowder;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtEstimate;
        private System.Windows.Forms.ToolTip powdercoatToolTip;
        private System.Windows.Forms.ToolTip materialToolTip;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pcbAwning;
        private System.Windows.Forms.PictureBox pcbFabricAwning;
    }
}

