﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace awningCalculator
{
    public partial class awningCalculator : Form
    {
        public awningCalculator()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int width, materialCost, powderCoatCost, totalCost, totalMaterialCost, totalPowderCoatingCost;
            const int metalFee = 175, fabricFee = 150, powderCoatFee = 25;

            int.TryParse(txtWidth.Text, out width);

            if (radFabric.Checked)
            {
                materialCost = fabricFee;
                pcbFabricAwning.Visible = true;
            }
            else
            {
                materialCost = metalFee;
                pcbAwning.Visible = true;
            }

            if (radYesPowder.Checked)
            {
                powderCoatCost = powderCoatFee;
            }
            else
            {
                powderCoatCost = 1;
            }

            totalMaterialCost = width * materialCost;
            totalPowderCoatingCost = width * powderCoatCost;
            totalCost = totalMaterialCost + totalPowderCoatingCost;
            
            txtEstimate.Text = totalCost.ToString("c");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtWidth.Text = "";
            txtEstimate.Text = "";
            pcbAwning.Visible = false;
            pcbFabricAwning.Visible = false;
        }
    }
}
